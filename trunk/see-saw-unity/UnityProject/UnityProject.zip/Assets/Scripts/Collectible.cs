﻿using UnityEngine;
using System.Collections;

public class Collectible : MonoBehaviour
{

    void Start()
    {

    }

    void Update()
    {

    }
}